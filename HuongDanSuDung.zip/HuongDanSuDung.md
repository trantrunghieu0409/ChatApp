﻿Hướng dẫn sử dụng

Sinh viên: Trần Trung Hiếu – 19127641

# Cách chạy Server
- Server nằm trong folder ServerSide\_jar.
- Có thể mở file ServerSide.jar bằng 2 cách:
  - Click chọn vào .jar
  - Sử dụng cmd để mở file .jar ( nên sử dụng  cách này để thấy được các thông tin kết nối ) 
- Màn hình giao diện sau sẽ hiện ra:

` `![Graphical user interface, application

Description automatically generated](Aspose.Words.71296d4f-0ff5-48f1-ad37-73dd9729a02a.001.png)

- Click button START để start server, click STOP để dừng server và thoát khỏi chương trình. 
# Cách chạy Client
- Server nằm trong folder ServerSide\_jar.
- Có thể mở file ServerSide.jar
- Nếu chưa mở Server, thì sẽ có thông báo chưa kết nối Server
- Nếu kết nối Server thành công, giao diện sau sẽ hiện ra

![Graphical user interface, application

Description automatically generated](Aspose.Words.71296d4f-0ff5-48f1-ad37-73dd9729a02a.002.png) 

- Điền thông tin tài khoản mật khẩu để đăng nhập, ở đây, sinh viên đã chuẩn bị sẵn 3 tài khoản
  - User: admin – pass: admin
  - User: test – pass: test
  - User: hieu – pass: 123
- Ngoài ra, có thể chọn Tab Register để đăng ký tài khoản.
- Sau khi đăng nhập thành công, giao diện sau sẽ hiện ra:

![Graphical user interface, text, application

Description automatically generated](Aspose.Words.71296d4f-0ff5-48f1-ad37-73dd9729a02a.003.png)

- Trên tiêu đề frame có tên user login hiện tại
- Nếu có một client khác đăng nhập, Online Now sẽ hiển thị tên Client đó. **Click vào client đó và bắt đầu Chat.**
- Nhập tin nhắn và **nhấn nút Send** để gửi tin nhắn ( phải chọn 1 client mới ở danh sách Online list có thể chat được ). Nếu client đăng nhập hoặc  thoát thì sẽ thông báo ở góc dưới bên trái màn hình.

![Graphical user interface, text, application

Description automatically generated](Aspose.Words.71296d4f-0ff5-48f1-ad37-73dd9729a02a.004.png)

- Để gửi file chọn Attachment -> Choose File -> Send.

![Graphical user interface, application

Description automatically generated](Aspose.Words.71296d4f-0ff5-48f1-ad37-73dd9729a02a.005.png)

- Client nhận được file, nếu muốn lưu lại file click YES và chọn thư mục để lưu trữ ( tên file sẽ được giữ như cũ)

![Graphical user interface, text

Description automatically generated](Aspose.Words.71296d4f-0ff5-48f1-ad37-73dd9729a02a.006.png)

- Chọn File -> Exit để thoát.
- Chọn File -> Sign out để đăng xuất.

